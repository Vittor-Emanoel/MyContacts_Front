export function Home() {
  return (
    <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="1" y="1" width="42" height="42" rx="21" fill="#FFF0F6"/>
    <path d="M14.4971 18.7754V27.4504C14.4971 29.1424 15.869 30.5143 17.561 30.5143H26.4403C28.1323 30.5143 29.5042 29.1424 29.5042 27.4504V18.7754" stroke="#F06595" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M31 19.9561L23.4741 13.9986C22.6101 13.3156 21.3899 13.3156 20.5259 13.9986L13 19.9561" stroke="#F06595" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M27.668 14.9434V17.2969" stroke="#F06595" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M19.6436 30.5142V26.7956C19.6436 25.995 19.6436 25.5947 19.7924 25.286C19.9398 24.9804 20.1864 24.7337 20.492 24.5864C20.8008 24.4375 21.2011 24.4375 22.0017 24.4375C22.8023 24.4375 23.2026 24.4375 23.5113 24.5864C23.8169 24.7337 24.0636 24.9804 24.2109 25.286C24.3598 25.5947 24.3598 25.995 24.3598 26.7956V30.5142" stroke="#F06595" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <rect x="1" y="1" width="42" height="42" rx="21" stroke="white" strokeWidth="2"/>
  </svg>
  );
}
