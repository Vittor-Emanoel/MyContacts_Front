export function Fun() {
  return (
    <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="1" y="1" width="42" height="42" rx="21" fill="#F3F0FF"/>
      <path d="M16.8569 18.2461L16.8695 19.3786C15.3692 20.0061 14.3428 21.4967 14.3428 23.2227C14.3428 25.5266 16.2147 27.3898 18.5196 27.3898H25.4907C27.7849 27.3898 29.6578 25.5266 29.6578 23.2227C29.6578 21.4967 28.6187 20.011 27.1184 19.3737L27.1515 18.284C27.1515 16.7303 26.5454 15.192 25.3477 14.2025C24.437 13.4514 23.2705 13 21.9998 13C20.5482 13 19.2337 13.5896 18.2832 14.5441C17.318 15.5131 16.8569 16.8781 16.8569 18.2461Z" stroke="#845EF7" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M19.8906 22.38L22.0009 24.4903" stroke="#845EF7" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M22 22.9698L24.1103 20.8595" stroke="#845EF7" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M22 31V19.6127" stroke="#845EF7" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <rect x="1" y="1" width="42" height="42" rx="21" stroke="white" strokeWidth="2"/>
    </svg>
  );
}
